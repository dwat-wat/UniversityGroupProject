﻿/*
 * Created by Dexter Watson DAW35
 */

using Microsoft.Azure.Cosmos.Table;
using System;

namespace APIGroupProject.Logging
{
    public class LogEntity:TableEntity
    {
        private DateTime timestamp;
        private string controller;
        private string message;
        private int statuscode;

        public DateTime TimeStamp
        {
            get
            {
                return timestamp;
            }

            set
            {
                timestamp = value;
            }
        }
        public string Controller
        {
            get
            {
                return controller;
            }

            set
            {
                controller = value;
            }
        }
        public string Message
        {
            get
            {
                return message;
            }

            set
            {
                message = value;
            }
        }
        public int StatusCode
        {
            get
            {
                return statuscode;
            }

            set
            {
                statuscode = value;
            }
        }
    }
}
