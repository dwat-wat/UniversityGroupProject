﻿/*
 * Created by Dexter Watson DAW35
 */

using APIGroupProject.Storage;
using Microsoft.Azure.Cosmos.Table;
using System;
using System.Threading.Tasks;

namespace APIGroupProject.Logging
{
    public class Logger : ILogger
    {
        CloudTable loggingTable;
        private const string CONTROLLER = "Accounts";

        public Logger(ITableClient client)
        {
            loggingTable = client.GetTableReference("Logging");
        }

        public void LogMessage(string message)
        {
            this.Log(message, 0);
        }

        public void LogMessage(string message, int statuscode)
        {
            this.Log(message, 200);
        }

        private void Log(string message, int statuscode)
        {
            // Fire and forget logging
            Task.Run(() => loggingTable.ExecuteAsync(TableOperation.Insert(new LogEntity()
            {
                PartitionKey = CONTROLLER,
                RowKey = Guid.NewGuid().ToString(),
                TimeStamp = DateTime.Now,
                Message = message,
                StatusCode = statuscode
            })));            
        }
    }
}
