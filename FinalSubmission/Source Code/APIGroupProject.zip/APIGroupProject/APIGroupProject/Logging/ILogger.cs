﻿/*
 * Created by Dexter Watson DAW35
 */

namespace APIGroupProject.Logging
{
    public interface ILogger
    {
        void LogMessage(string message);
        void LogMessage(string message, int statuscode);
    }
}
