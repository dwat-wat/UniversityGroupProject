﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APIGroupProject.ViewModels
{
    public class OutputResult
    {
        public List<FinalResult> FinalResults { get; set; }
        public double? AccountBalance { get; set; }
        public double? CurrentOwned { get; set; }
    }
}
