﻿using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APIGroupProject.ViewModels
{
    public class PositionsEntity : TableEntity
    {
        public PositionsEntity() { }

        public string PartitionKey { get; set; }
        public Guid RowKey { get; set; }
        public DateTime TimeStamp { get; set; }
        public string UserName { get; set; }
        public int Quantity { get; set; }
        public string PositionType { get; set; }
    }
}
