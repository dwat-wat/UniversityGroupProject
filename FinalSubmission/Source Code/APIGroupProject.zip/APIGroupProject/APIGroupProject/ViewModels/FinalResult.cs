﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APIGroupProject.ViewModels
{
    public class FinalResult
    {
        public int BitCoinOwned { get; set; }
        public double? CurrentBitCoinValue { get; set; }
        public DateTime TimeStamp { get; set; }
        public string Week { get; set; }
    }
}
