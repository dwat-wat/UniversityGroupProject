﻿using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APIGroupProject.ViewModels
{
    public class Portfolios : TableEntity
    {
        public Portfolios() { }

        public string PartitionKey { get; set; }
        public Guid RowKey { get; set; }
        public DateTime TimeStamp { get; set; }
        public double BTC { get; set; }
        public double GBP { get; set; }
        public double Start { get; set; }
        public double StartGBP { get; set; }
    }
}
