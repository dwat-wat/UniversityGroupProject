﻿/*
 * Created by Dexter Watson DAW35
 */

using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Cosmos.Table;
using APIGroupProject.Models;
using APIGroupProject.Logging;
using APIGroupProject.Storage;
using System.Net.Http;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Linq;

namespace APIGroupProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdministrationController : ControllerBase
    {
        private const int WORKFACTORITERATIONS = 1;

        CloudTable accountsTable;
        ILogger logger;

        public AdministrationController(ITableClient client, ILogger _logger)
        {
            try
            {
                logger = _logger;
                accountsTable = client.GetTableReference("Accounts");
            }
            catch(Exception e)
            {
                logger.LogMessage($"Accounts controller failed to initialise:\n{e.Message}", 500);
            }
        }

        // POST: api/administration/login
        [HttpPost("login")]
        public async Task<HttpResponseMessage> LoginAsync(Account details)
        {
            bool isFound = false;
            
            // Format region and username
            details.region = details.region.ToUpper();
            details.username = details.username.ToUpper();

            // Retrieve account entity from table
            var result = await accountsTable.ExecuteAsync(TableOperation.Retrieve<AccountEntity>(details.region, details.username));
            var objResult = result.Result as AccountEntity;

            if(objResult == null)
            {
                logger.LogMessage($"LoginAsync - Region:{details.region} Username:{details.username}", 400);
                return new HttpResponseMessage(HttpStatusCode.BadRequest);
            }

            // Calculate password hash
            var password = Encoding.ASCII.GetBytes(details.password);
            var passwordSalt = GenerateSalt(password.Length);
            var passwordHash = GenerateHash(password, objResult.PasswordSalt, objResult.PasswordWorkFactor, password.Length);

            // Compare password hash
            if (objResult != null 
                && passwordHash.SequenceEqual(objResult?.PasswordHash)
                && objResult.Role == "ADMIN")
            {
                isFound = true;
            }

            if (isFound)
            {
                logger.LogMessage($"LoginAsync - Region:{details.region} Username:{details.username}", 200);
                return new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent(new Guid().ToString()) };
            }
            else
            {
                logger.LogMessage($"LoginAsync - Region:{details.region} Username:{details.username}", 400);
                return new HttpResponseMessage(HttpStatusCode.BadRequest);
            }
        }

        // Private methods for Password-Based Key Derivation Function (PBKDF)
        // More info: https://www.mking.net/blog/password-security-best-practices-with-examples-in-csharp

        private byte[] GenerateSalt(int length)
        {
            var bytes = new byte[length];

            using (var rng = new RNGCryptoServiceProvider())
            {
                rng.GetBytes(bytes);
            }

            return bytes;
        }

        private byte[] GenerateHash(byte[] password, byte[] salt, int iterations, int length)
        {
            using (var deriveBytes = new Rfc2898DeriveBytes(password, salt, iterations))
            {
                return deriveBytes.GetBytes(length);
            }
        }
    }
}
