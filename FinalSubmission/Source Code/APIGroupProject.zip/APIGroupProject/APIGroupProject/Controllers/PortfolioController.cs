﻿/* 
 * Created by Dexter Watson DAW35
 */

using System;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using APIGroupProject.Logging;
using APIGroupProject.Models;
using APIGroupProject.Storage;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Cosmos.Table;

namespace APIGroupProject.Controllers
{
    [Route("api/[controller]")]
    public class PortfolioController : ControllerBase
    {
        CloudTable portfolioTable;
        CloudTable accountsTable;
        ILogger logger;

        public PortfolioController(ITableClient client, ILogger _logger)
        {
            try
            {
                logger = _logger;
                portfolioTable = client.GetTableReference("Portfolios");
                accountsTable = client.GetTableReference("Accounts");
            }
            catch (Exception e)
            {
                logger.LogMessage($"Accounts controller failed to initialise:\n{e.Message}", 500);
            }
        }

        // GET: api/portfolio/username
        [HttpGet]
        public async Task<IActionResult> GetAllPortfoliosAsync(string username)
        {
            // Format username
            username = username.ToUpper();

            TableQuery<PortfolioEntity> query = new TableQuery<PortfolioEntity>().Where(
                    TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, username)
                );

            var result = portfolioTable.ExecuteQuery(query);

            if (result.Count() == 0)
            {
                logger.LogMessage($"GetDataAsync - Username: {username}", 404);
                return new NotFoundResult();
            }

            return new OkObjectResult(result);
        }

        // GET: api/portfolio/get/user/portfolio
        [HttpGet("get")]
        public async Task<IActionResult> GetPortfolioAsync(string username, string portfolio)
        {
            // Format username and portfolio
            username = username.ToUpper();
            portfolio = portfolio.ToUpper();

            // Retrieve account entity from table
            var result = await portfolioTable.ExecuteAsync(TableOperation.Retrieve<PortfolioEntity>(username, portfolio));
            var objResult = result.Result as PortfolioEntity;

            if (objResult == null)
            {
                logger.LogMessage($"GetAccountDetailsAsync - Username:{username}, Portfolio:{portfolio}", 404);
                return new NotFoundResult();
            }

            // Get the account entity
            var acc = await accountsTable.ExecuteAsync(TableOperation.Retrieve<AccountEntity>("UK", username));
            var uacc = acc.Result as AccountEntity;
            uacc.SelectedPortfolio = portfolio;

            // Set the selected portfolio
            await accountsTable.ExecuteAsync(TableOperation.Replace(uacc));

            return new OkObjectResult(objResult);
        }

        // POST: api/portfolio/new/username/portfolio/amount
        [HttpPost("new")]
        public async Task<IActionResult> NewPortfolioAsync(string username, string portfolio, double amount)
        {
            // Format portfolio and username
            portfolio = portfolio.ToUpper();
            username = username.ToUpper();

            // Check that the portfolio does not already exist
            var existingportfolio = await portfolioTable.ExecuteAsync(TableOperation.Retrieve<PortfolioEntity>(username, portfolio));
            if (existingportfolio.HttpStatusCode != (int)HttpStatusCode.NotFound)
            {
                return new BadRequestResult();
            }

            var portfolioEntity = new PortfolioEntity()
            {
                PartitionKey = username,
                RowKey = portfolio,
                GBP = amount,
                BTC = 0,
                Start = DateTime.Now,
                StartGBP = amount,
                Deleted = false
            };

            // Insert the new portfolio into the portfolios table
            await portfolioTable.ExecuteAsync(TableOperation.Insert(portfolioEntity));

            logger.LogMessage($"NewPortfolioAsync: Username: {username}, Portfolio: {portfolio}, Amount: {amount}", 201);

            return new CreatedResult(username, portfolioEntity);
        }

        // PUT: api/portfolio/update/username/portfolio/gbp/btc
        [HttpPut("update")]
        public async Task<IActionResult> UpdatePortfolio(string username, string portfolio, double gbp, double btc)
        {
            // Format portfolio and username
            portfolio = portfolio.ToUpper();
            username = username.ToUpper();

            // Check that the portfolio does exist
            var existingportfolio = await portfolioTable.ExecuteAsync(TableOperation.Retrieve<PortfolioEntity>(username, portfolio));
            if (existingportfolio.HttpStatusCode == (int)HttpStatusCode.NotFound)
            {
                return new NotFoundResult();
            }

            var portfolioEntity = existingportfolio.Result as PortfolioEntity;
            portfolioEntity.BTC = btc;
            portfolioEntity.GBP = gbp;

            // Insert the new portfolio into the portfolios table
            await portfolioTable.ExecuteAsync(TableOperation.InsertOrReplace(portfolioEntity));

            return new CreatedResult(username, portfolioEntity);

        }

        [HttpPut("delete")]
        public async Task<IActionResult> DeletePortfolio(string username, string portfolio)
        {
            // Format portfolio and username
            portfolio = portfolio.ToUpper();
            username = username.ToUpper();

            // Check that the portfolio does exist
            var existingportfolio = await portfolioTable.ExecuteAsync(TableOperation.Retrieve<PortfolioEntity>(username, portfolio));
            if (existingportfolio.HttpStatusCode == (int)HttpStatusCode.NotFound)
            {
                logger.LogMessage($"DeletePortfolio: Username: {username}, Portfolio: {portfolio}", 404);
                return new OkResult();
            }

            var portfolioEntity = existingportfolio.Result as PortfolioEntity;
            portfolioEntity.Deleted = true;

            // Insert the new portfolio into the portfolios table
            await portfolioTable.ExecuteAsync(TableOperation.InsertOrReplace(portfolioEntity));
            logger.LogMessage($"DeletePortfolio: Username: {username}, Portfolio: {portfolio}", 200);

            return new OkResult();
        }
    }
}
