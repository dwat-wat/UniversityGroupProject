﻿/*
 * Created by Dexter Watson DAW35
 */

using Microsoft.AspNetCore.Mvc;

namespace APIGroupProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StatusController : ControllerBase
    {
        // GET api/status
        [HttpGet]
        public ActionResult<string> GetStatus()
        {
            return "The API is running.";
        }
    }
}
