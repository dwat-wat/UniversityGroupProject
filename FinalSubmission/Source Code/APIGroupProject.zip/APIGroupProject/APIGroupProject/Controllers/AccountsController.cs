﻿/*
 * Created by Dexter Watson DAW35
 */

using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Cosmos.Table;
using APIGroupProject.Models;
using APIGroupProject.Logging;
using APIGroupProject.Storage;
using System.Net.Http;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Linq;

namespace APIGroupProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountsController : ControllerBase
    {
        private const int WORKFACTORITERATIONS = 1;

        CloudTable accountsTable;
        CloudTable portfoliosTable;
        ILogger logger;

        public AccountsController(ITableClient client, ILogger _logger)
        {
            try
            {
                logger = _logger;
                accountsTable = client.GetTableReference("Accounts");
                portfoliosTable = client.GetTableReference("Portfolios");
            }
            catch(Exception e)
            {
                logger.LogMessage($"Accounts controller failed to initialise:\n{e.Message}", 500);
            }
        }

        // GET: api/accounts/details/user
        [HttpGet("details")]
        public async Task<IActionResult> GetAccountDetailsAsync(string region, string username)
        {
            // Format region and username
            region = region.ToUpper();
            username = username.ToUpper();

            // Retrieve account entity from table
            var result = await accountsTable.ExecuteAsync(TableOperation.Retrieve<AccountEntity>(region, username));
            var objResult = result.Result as AccountEntity;

            if (objResult == null)
            {
                logger.LogMessage($"GetAccountDetailsAsync - Region:{region} Username:{username}", 404);
                return new NotFoundResult();
            }

            var acc = new AccountEntity()
            {
                UserName = objResult.RowKey,
                SelectedPortfolio = objResult.SelectedPortfolio == null ? "default" : objResult.SelectedPortfolio
            };

            return new OkObjectResult(acc);
        }

        // POST: api/accounts/login
        [HttpPost("login")]
        public async Task<HttpResponseMessage> LoginAsync(Account details)
        {
            bool isFound = false;
            
            // Format region and username
            details.region = details.region.ToUpper();
            details.username = details.username.ToUpper();

            // Retrieve account entity from table
            var result = await accountsTable.ExecuteAsync(TableOperation.Retrieve<AccountEntity>(details.region, details.username));
            var objResult = result.Result as AccountEntity;

            if(objResult == null)
            {
                logger.LogMessage($"LoginAsync - Region:{details.region} Username:{details.username}", 400);
                return new HttpResponseMessage(HttpStatusCode.BadRequest);
            }

            // Calculate password hash
            var password = Encoding.ASCII.GetBytes(details.password);
            var passwordSalt = GenerateSalt(password.Length);
            var passwordHash = GenerateHash(password, objResult.PasswordSalt, objResult.PasswordWorkFactor, password.Length);

            // Compare password hash
            if (objResult != null && passwordHash.SequenceEqual(objResult?.PasswordHash))
            {
                isFound = true;
            }

            if (isFound)
            {
                logger.LogMessage($"LoginAsync - Region:{details.region} Username:{details.username}", 200);
                return new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent(new Guid().ToString()) };
            }
            else
            {
                logger.LogMessage($"LoginAsync - Region:{details.region} Username:{details.username}", 400);
                return new HttpResponseMessage(HttpStatusCode.BadRequest);
            }
        }
        
        // POST: api/Accounts
        [HttpPost ("new")]
        public async Task<HttpResponseMessage> NewAsync([FromBody] Account newaccount)
        {
            if(newaccount.password.Length < 8)
            {
                return new HttpResponseMessage(HttpStatusCode.BadRequest);
            }

            // Format region and username
            newaccount.region = newaccount.region.ToUpper();
            newaccount.username = newaccount.username.ToUpper();

            // Check that the user does not already exist
            var existingaccount = await accountsTable.ExecuteAsync(TableOperation.Retrieve<AccountEntity>(newaccount.region, newaccount.username));
            if (existingaccount.HttpStatusCode != (int) HttpStatusCode.NotFound)
            {
                return new HttpResponseMessage(HttpStatusCode.BadRequest);
            }

            var password = Encoding.ASCII.GetBytes(newaccount.password);
            var passwordSalt = GenerateSalt(password.Length);
            var passwordHash = GenerateHash(password, passwordSalt, WORKFACTORITERATIONS, password.Length);

            // Insert the new account into the accounts table
            await accountsTable.ExecuteAsync(TableOperation.Insert(new AccountEntity()
            {
                PartitionKey = newaccount.region,
                RowKey = newaccount.username,
                Role = "USER",
                SelectedPortfolio = "DEFAULT",
                PasswordSalt = passwordSalt,
                PasswordHash = passwordHash,
                PasswordWorkFactor = WORKFACTORITERATIONS
            }));

            
            // Check that the operation was successfull
            var result = await accountsTable.ExecuteAsync(TableOperation.Retrieve<AccountEntity>(newaccount.region, newaccount.username));
            var objResult = result.Result as AccountEntity;
            if (objResult != null)
            {
                // Insert default portfolio
                await portfoliosTable.ExecuteAsync(TableOperation.Insert(new PortfolioEntity() { StartGBP = 10000, GBP = 10000, BTC = 0, Deleted = false, PartitionKey = newaccount.username, Portfolio = "DEFAULT", Start = DateTime.Now, RowKey = "DEFAULT", UserName = newaccount.username }));

                logger.LogMessage($"NewAsync - Region:{newaccount.region} Username:{newaccount.username}", 201);
                return new HttpResponseMessage(HttpStatusCode.Created) { Content = new StringContent(new Guid().ToString()) };
            }
            else
            {
                logger.LogMessage($"NewAsync - Region:{newaccount.region} Username:{newaccount.username}", 400);
                newaccount.password = null;
                return new HttpResponseMessage(HttpStatusCode.BadRequest);
            }
        }

        // Private methods for Password-Based Key Derivation Function (PBKDF)
        // More info: https://www.mking.net/blog/password-security-best-practices-with-examples-in-csharp

        private byte[] GenerateSalt(int length)
        {
            var bytes = new byte[length];

            using (var rng = new RNGCryptoServiceProvider())
            {
                rng.GetBytes(bytes);
            }

            return bytes;
        }

        private byte[] GenerateHash(byte[] password, byte[] salt, int iterations, int length)
        {
            using (var deriveBytes = new Rfc2898DeriveBytes(password, salt, iterations))
            {
                return deriveBytes.GetBytes(length);
            }
        }
    }
}
