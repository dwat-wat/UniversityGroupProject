﻿/*
 * Created by Dexter Watson DAW35
 */

using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Cosmos.Table;
using APIGroupProject.Models;
using APIGroupProject.Logging;
using APIGroupProject.Storage;
using System.Net.Http;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.Threading;

namespace APIGroupProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PredictionController : ControllerBase
    {
        CloudTable predictionDataTable;
        ILogger logger;

        public PredictionController(ITableClient client, ILogger _logger)
        {
            try
            {
                logger = _logger;
                predictionDataTable = client.GetTableReference("PredictionData");
            }
            catch(Exception e)
            {
                logger.LogMessage($"Accounts controller failed to initialise:\n{e.Message}", 500);
            }
        }

        // GET: api/prediction/data
        [HttpGet("data")]
        public async Task<IActionResult> GetDataAsync(string _currency, DateTime _from, DateTime _to)
        {
            // Format from and to
            var currency = _currency.ToUpper();
            var from = _from.Year.ToString().Substring(2) + _from.DayOfYear.ToString().PadLeft(3, '0');
            var to = _to.Year.ToString().Substring(2) + _to.DayOfYear.ToString().PadLeft(3, '0');

            TableQuery<PredictionDataEntity> query = new TableQuery<PredictionDataEntity>().Where(
                TableQuery.CombineFilters(
                    TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, currency),
                    TableOperators.And,
                    TableQuery.CombineFilters(
                        TableQuery.GenerateFilterCondition("RowKey", QueryComparisons.GreaterThanOrEqual, from),
                        TableOperators.And,
                        TableQuery.GenerateFilterCondition("RowKey", QueryComparisons.LessThan, to)))
                );

            var result = predictionDataTable.ExecuteQuery(query);

            if (result.Count() == 0)
            {
                logger.LogMessage($"GetDataAsync - Currency:{_currency} From:{_from} To:{_to}", 404);
                return new NotFoundResult();
            }

            return new OkObjectResult(result);
        }
    }
}
