/** 
 * 
 * Created By Connor Taylor ct401
 * 
 * **/


using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Cosmos.Table;
using APIGroupProject.Models;
using APIGroupProject.Logging;
using APIGroupProject.Storage;
using System.Net.Http;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.Threading;

namespace APIGroupProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LiveAndHistoricalDataController : ControllerBase
    {
        CloudTable LiveAndHistoricalDataTable;
        ILogger logger;

        public LiveAndHistoricalDataController(ITableClient client, ILogger _logger)
        {
            try
            {
                logger = _logger;
                LiveAndHistoricalDataTable = client.GetTableReference("CryptoCompareAPIDataFinal");
            }
            catch (Exception e)
            {
                logger.LogMessage($"Failure to initialise:\n{e.Message}", 500);
            }
        }

        
        [HttpGet("data")]
        public async Task<IActionResult> GetLiveAndHistoricalDataAsync(string currency, string before, string now)
        {
            var baseCurrency = currency.ToUpper();
            var beforey = before.Replace(".", " ");
            var nowy = now.Replace(".", " ");

            TableQuery<LiveAndHistoricalDataEntity> tablesquery = new TableQuery<LiveAndHistoricalDataEntity>().Where(
                TableQuery.CombineFilters(TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, baseCurrency),
                    TableOperators.And, TableQuery.CombineFilters(TableQuery.GenerateFilterCondition("RowKey", QueryComparisons.GreaterThanOrEqual, beforey),
                        TableOperators.And, TableQuery.GenerateFilterCondition("RowKey", QueryComparisons.LessThanOrEqual, nowy))));

            var theresult = LiveAndHistoricalDataTable.ExecuteQuery(tablesquery);
            if (theresult.Count() == 0)
            {
                logger.LogMessage($"GetDataAsync - Currency:{currency} Before:{before} Now:{now}", 404);
                return new NotFoundResult();
            }
            return new OkObjectResult(theresult);
        }

        [HttpGet("onedata")]
        public async Task<IActionResult> GetLiveAndHistoricalDataAltAsync(string currency, DateTime before, DateTime now)
        {
            var baseCurrency = currency.ToUpper();
            var beforey = before.Year.ToString().Substring(2) + before.DayOfYear.ToString().PadLeft(3, '0');
            var nowy = now.Year.ToString().Substring(2) + now.DayOfYear.ToString().PadLeft(3, '0');
            

            TableQuery<LiveAndHistoricalDataEntity> tablesquery = new TableQuery<LiveAndHistoricalDataEntity>().Where(
                TableQuery.CombineFilters(TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, baseCurrency),
                    TableOperators.And, TableQuery.CombineFilters(TableQuery.GenerateFilterCondition("RowKey", QueryComparisons.GreaterThanOrEqual, beforey),
                        TableOperators.And, TableQuery.GenerateFilterCondition("RowKey", QueryComparisons.LessThanOrEqual, nowy))));

            var theresult = LiveAndHistoricalDataTable.ExecuteQuery(tablesquery);
            if (theresult.Count() == 0)
            {
                logger.LogMessage($"GetDataAsync - Currency:{currency} Before:{before} Now:{now}", 404);
                return new NotFoundResult();
            }
            return new OkObjectResult(theresult);
        }

        [HttpGet("twodata")]
        public async Task<IActionResult> GetPriceNowAsync(string currency)
        {
            //var currencyy = currency.ToUpper();
            DateTime sTime = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            var nowUnix = (long)(DateTime.Now - sTime).TotalSeconds;
            var nowFromUnix = (long)(DateTime.Now.AddDays(-1) - sTime).TotalSeconds;


            TableQuery<LiveAndHistoricalDataEntity> tablesquery = new TableQuery<LiveAndHistoricalDataEntity>().Where(
                TableQuery.CombineFilters(
                    TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, currency),
                    TableOperators.And, 
                    //TableQuery.CombineFilters(
                    //    TableQuery.GenerateFilterCondition("Time", QueryComparisons.GreaterThanOrEqual, nowFromUnix.ToString()),
                    //    TableOperators.And,
                        TableQuery.GenerateFilterCondition("Time", QueryComparisons.LessThanOrEqual, nowUnix.ToString())))
                //)
                ;

            var theresult = LiveAndHistoricalDataTable.ExecuteQuery(tablesquery);
            if (theresult.Count() == 0)
            {
                logger.LogMessage($"GetDataAsync - Currency:{currency} Now:{nowUnix}", 404);
                return new NotFoundResult();
            }
            return new OkObjectResult(theresult);
        }
    }
}