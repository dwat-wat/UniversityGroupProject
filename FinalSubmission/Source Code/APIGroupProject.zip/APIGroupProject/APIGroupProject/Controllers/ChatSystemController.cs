﻿/*
 * Created by Mehmet Karauc MK622
 */

using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using APIGroupProject.Storage;
using APIGroupProject.Logging;
using APIGroupProject.Models;
using Microsoft.Azure.Cosmos.Table;
using Microsoft.Azure.Cosmos.Table.Queryable;
using System.Net.Http;
using System.Net;
using System.Linq;
using System.Threading;
using APIGroupProject.Extensions;

namespace APIGroupProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ChatSystemController : ControllerBase
    {
        CloudTable chatSystemTable;
        ILogger logger;

        private const string CONTROLLER = "ChatSystems";

        public ChatSystemController(ITableClient client, ILogger _logger)
        {
            try
            {
                logger = _logger;
                chatSystemTable = client.GetTableReference("ChatSystem");
            }
            catch (Exception e)
            {
                logger.LogMessage($"ChatSystem controller failed to initialise:\n{e.Message}", 500);
            }
        }

        // GET: api/chatsystem/data
        [HttpGet("data")]
        public async Task<IActionResult> GetMessageAsync()
        {

            DateTimeOffset time = DateTime.Now;
            var to = time.ToUnixTimeSeconds();
            var from = time.AddDays(-1).ToUnixTimeSeconds();

            // Retrieve message entity from table
            var query = chatSystemTable.CreateQuery<ChatSystemsEntity>()
                //.Where(x => x.Time >= from && x.Time < to)
                .Select(x => new ChatSystemsEntity() { UserName = x.UserName, History = x.History, TimeStamp = x.TimeStamp })
                .AsTableQuery();

            var cancellationToken = new CancellationToken();

            var result = await query.ExecuteAsync(cancellationToken);

            if (result.Count() == 0)
            {
                logger.LogMessage($"GetMessageAsync", 404);
                return new NotFoundResult();
            }

            var res = result.OrderByDescending(x => x.TimeStamp).Take(50).ToList();

            return new OkObjectResult(res);
        }

        // POST: api/chatsystem/insert
        [HttpPost("insert")]
        public async Task<HttpResponseMessage> NewAsync([FromBody] ChatSystems newchatSystem)
        {

            // Insert the new message into the positions table
            var res = await chatSystemTable.ExecuteAsync(TableOperation.Insert(new ChatSystemsEntity()
            {
                PartitionKey = newchatSystem.userName,
                RowKey = Guid.NewGuid().ToString(),
                TimeStamp = DateTime.Now,
                History = newchatSystem.history
            }));
            return new HttpResponseMessage((HttpStatusCode) res.HttpStatusCode);
        }
    }
}





