﻿/*
 * Created by Mehmet Karauc MK622
 */

using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using APIGroupProject.Storage;
using APIGroupProject.Logging;
using Microsoft.Azure.Cosmos.Table;
using Microsoft.Azure.Cosmos.Table.Queryable;
using System.Net.Http;
using System.Net;
using APIGroupProject.Models;
using System.Linq;
using System.Threading;
using APIGroupProject.Extensions;

namespace APIGroupProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ForumController : ControllerBase
    {
        CloudTable forumTable;
        ILogger logger;

        private const string CONTROLLER = "Forum";

        public ForumController(ITableClient client, ILogger _logger)
        {
            try
            {
                logger = _logger;
                forumTable = client.GetTableReference("Forum");
            }
            catch (Exception e)
            {
                logger.LogMessage($"Forum controller failed to initialise:\n{e.Message}", 500);
            }
        }

        // GET: api/forum/data
        [HttpGet("data")]
        public async Task<IActionResult> GetMessageAsync()
        {

            // Retrieve all entities from table
            var query = forumTable.CreateQuery<ForumEntity>()
                .Select(x => new ForumEntity() { UserName = x.UserName, Question = x.Question, Reply = x.Reply, TimeStamp = x.TimeStamp })
                .AsTableQuery();

            var cancellationToken = new CancellationToken();

            var result = await query.ExecuteAsync(cancellationToken);

            if (result.Count() == 0)
            {
                logger.LogMessage($"GetMessageAsync", 404);
                return new NotFoundResult();
            }

            // Order entities in descending order by the timestamp
            var res = result.OrderByDescending(x => x.TimeStamp).ToList();

            return new OkObjectResult(res);
        }

        // POST: api/forum/insert
        [HttpPost("insert")]
        public async Task<HttpResponseMessage> NewAsync([FromBody] Forum newforum)
        {

            // Insert the new forum question/reply into the forum table
            var res = await forumTable.ExecuteAsync(TableOperation.Insert(new ForumEntity()
            {
                PartitionKey = newforum.userName,
                RowKey = Guid.NewGuid().ToString(),
                TimeStamp = DateTime.Now,
                Question = newforum.question,
                Reply = newforum.reply,
            }));
            return new HttpResponseMessage((HttpStatusCode)res.HttpStatusCode);
        }
    }
}