﻿/*
 * Created by Dexter Watson DAW35
 */

using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Cosmos.Table;
using Microsoft.Azure.Cosmos.Table.Queryable;
using APIGroupProject.Models;
using APIGroupProject.Logging;
using APIGroupProject.Storage;
using System.Net.Http;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.Threading;
using APIGroupProject.Extensions;

namespace APIGroupProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CryptoDataController : ControllerBase
    {

        CloudTable predictionDataTable;
        ILogger logger;

        public CryptoDataController(ITableClient client, ILogger _logger)
        {
            try
            {
                logger = _logger;
                predictionDataTable = client.GetTableReference("CryptoCompareAPIDataFinal");
            }
            catch (Exception e)
            {
                logger.LogMessage($"Accounts controller failed to initialise:\n{e.Message}", 500);
            }
        }

        // GET: api/CryptoData/data
        [HttpGet("live-recent")]
        public async Task<IActionResult> GetDataAsync(string _currency)
        {
            var currency = _currency.ToUpper();
            
            DateTimeOffset time = DateTime.Now;
            var to = time.ToUnixTimeSeconds();
            var from = time.AddMinutes(-1).ToUnixTimeSeconds();

            TableQuery<CryptoDataEntity> query = predictionDataTable.CreateQuery<CryptoDataEntity>()
                .Where(d => 
                    d.PartitionKey == currency &&
                    d.Time >= from && d.Time < to)
                .Take(1)
                .AsTableQuery();

            var cancellationToken = new CancellationToken();

            var result = await query.ExecuteAsync(cancellationToken);

            if (result == null)
            {
                logger.LogMessage($"GetDataAsync - Currency:{_currency} From:{from} To:{to}", 404);
                return new NotFoundResult();
            }

            return new OkObjectResult(result);
        }

        // GET: api/CryptoData/data
        [HttpGet("recent")]
        public async Task<IActionResult> GetRecentDataAsync(string _currency)
        {
            var currency = _currency.ToUpper();

            DateTimeOffset time = DateTime.Now;
            var to = time.ToUnixTimeSeconds();
            var from = time.AddMinutes(-1).ToUnixTimeSeconds();

            TableQuery<CryptoDataEntity> query = predictionDataTable.CreateQuery<CryptoDataEntity>()
                .Where(d =>
                    d.PartitionKey == currency &&
                    d.Time >= from && d.Time < to)
                .Take(1)
                .AsTableQuery();

            var cancellationToken = new CancellationToken();

            var result = await query.ExecuteAsync(cancellationToken);

            if (result == null)
            {
                logger.LogMessage($"GetDataAsync - Currency:{_currency} From:{from} To:{to}", 404);
                return new NotFoundResult();
            }

            return new OkObjectResult(result);
        }
        

        // GET: api/CryptoData/data
        [HttpGet("data")]
        public async Task<IActionResult> GetAmountDataAsync(string _currency, int _amount)
        {
            var currency = _currency.ToUpper();

            DateTimeOffset time = DateTime.Now;
            var to = time.ToUnixTimeSeconds();
            var from = time.AddHours(-3).ToUnixTimeSeconds();


            TableQuery<CryptoDataEntity> query = predictionDataTable.CreateQuery<CryptoDataEntity>()
                .Where(d =>
                    d.PartitionKey == currency &&
                    d.Time >= from && d.Time < to)
                .Select(x => new CryptoDataEntity() { PartitionKey = x.PartitionKey, RowKey = x.RowKey, Close = x.Close, Currency = x.Currency, Time = x.Time, High = x.High, Low = x.Low, Open = x.Open, Timestamp = x.Timestamp})
                .AsTableQuery();

            var cancellationToken = new CancellationToken();

            var result = await query.ExecuteAsync(cancellationToken);

            if (result == null)
            {
                logger.LogMessage($"GetAmountDataAsync - Currency:{_currency}", 404);
                return new NotFoundResult();
            }

            var res = result.OrderByDescending(x => x.Time).Take(_amount);

            return new OkObjectResult(res);
        }


        // GET: api/CryptoData/data
        [HttpGet("tofrom")]
        public async Task<IActionResult> GetToFromDataAsync(string _currency, DateTime _to, DateTime _from, int _frequency)
        {
            var currency = _currency.ToUpper();

            DateTimeOffset tod = _to;
            DateTimeOffset frd = _from;
            var to = tod.ToUnixTimeSeconds();
            var from = frd.ToUnixTimeSeconds();


            TableQuery<CryptoDataEntity> query = predictionDataTable.CreateQuery<CryptoDataEntity>()
                .Where(d =>
                    d.PartitionKey == currency &&
                    d.Time >= from && d.Time < to )
                .Select(x => new CryptoDataEntity() { PartitionKey = x.PartitionKey, RowKey = x.RowKey, Close = x.Close, Currency = x.Currency, Time = x.Time, High = x.High, Low = x.Low, Open = x.Open, Timestamp = x.Timestamp })
                .AsTableQuery();

            var cancellationToken = new CancellationToken();

            var result = await query.ExecuteAsync(cancellationToken);

            if (result == null)
            {
                logger.LogMessage($"GetAmountDataAsync - Currency:{_currency}", 404);
                return new NotFoundResult();
            }

            var res = result.OrderByDescending(x => x.Time).Where(d => d.Time % (60 * _frequency) == 0);

            return new OkObjectResult(res);
        }
    }
}



