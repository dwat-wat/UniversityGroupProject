﻿/*
 * Created by Mehmet Karauc MK622
 */

using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using APIGroupProject.Storage;
using APIGroupProject.Logging;
using Microsoft.Azure.Cosmos.Table;
using System.Net.Http;
using System.Net;
using APIGroupProject.Models;
using System.Linq;
using System.Collections.Generic;

namespace APIGroupProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PositionsController : ControllerBase
    {
        CloudTable positionsTable;
        ILogger logger;

        private const string CONTROLLER = "Positions";
      
        public PositionsController(ITableClient client, ILogger _logger)
        {
            try
            {
                logger = _logger;
                positionsTable = client.GetTableReference("Positions");
            }
            catch (Exception e)
            {
                logger.LogMessage($"Position controller failed to initialise:\n{e.Message}", 500);
            }
        }

        // GET: api/positions/portfoliodata
        [HttpGet("portfoliodata")]
        public async Task<IActionResult> GetPortfolioPositionsAsync(string userName, string portfolio)
        {
            // Format portfolio
            portfolio = portfolio.ToUpper();

            // Retrieve portfolio entity from table
            TableQuery<PositionEntity> query = new TableQuery<PositionEntity>().Where(
                TableQuery.CombineFilters(
                    TableQuery.GenerateFilterCondition("UserName", QueryComparisons.Equal, userName),
                    TableOperators.And,
                        TableQuery.GenerateFilterCondition("Portfolio", QueryComparisons.Equal, portfolio)));

            var result = positionsTable.ExecuteQuery(query);

            //if (result.Count() == 0)
            //{
            //    logger.LogMessage($"GetPositionsAsync - Username: { userName } Portfolio: { portfolio }", 404);
            //    return new NotFoundResult();
            //}

            // Order entities in descending order by the timestamp
            var res = result.OrderByDescending(x => x.TimeStamp).ToList();

            return new OkObjectResult(res);
        }

        // GET: api/positions/data
        [HttpGet("data")]
        public async Task<IActionResult> GetPositionsAsync(string userName, string currency)
        {

            // Retrieve position entity from table
            TableQuery<PositionEntity> query = new TableQuery<PositionEntity>().Where(
            TableQuery.CombineFilters(
                    TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, currency),
                    TableOperators.And,
                    TableQuery.GenerateFilterCondition("UserName", QueryComparisons.Equal, userName)));

            var result = positionsTable.ExecuteQuery(query);

            if (result.Count() == 0)
            {
                logger.LogMessage($"GetPositionsAsync - Username: { userName } Currency: { currency }", 404);
                return new NotFoundResult();
            }

            // Order entities in descending order by the timestamp
            var res = result.OrderByDescending(x => x.TimeStamp).ToList();

            return new OkObjectResult(res);
        }

        // POST: api/positions/insert
        [HttpPost("insert")]
        public async Task<HttpResponseMessage> NewAsync([FromBody] Position newposition)
        {

            // Format currency
            newposition.currency = newposition.currency.ToUpper();
            
            // Insert the new position into the positions table
            var res = await positionsTable.ExecuteAsync(TableOperation.Insert(new PositionEntity()
            {
                PartitionKey = newposition.currency,
                RowKey = Guid.NewGuid().ToString(),
                TimeStamp = DateTime.Now,
                UserName = newposition.userName,
                Quantity = newposition.quantity,
                PositionType = newposition.positionType,
                Portfolio = newposition.portfolio
            }));
            return new HttpResponseMessage((HttpStatusCode) res.HttpStatusCode);
        }
    }
}




