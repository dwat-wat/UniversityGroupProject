﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using APIGroupProject.Storage;
using APIGroupProject.Logging;
using Microsoft.Azure.Cosmos.Table;
using System.Net.Http;
using System.Net;
using APIGroupProject.Models;
using System.Linq;
using System.Collections.Generic;
using APIGroupProject.ViewModels;

namespace APIGroupProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BitcoinController : ControllerBase
    {
        CloudTable positionsTable;
        ILogger logger;

        private const string CONTROLLER = "Bitcoin";
      
        public BitcoinController(ITableClient client, ILogger _logger)
        {
        }


        [HttpGet]
        public async Task<ActionResult<OutputResult>> GetAsync(string user, string startD, string endD )
        {
            DateTime startDate = Convert.ToDateTime(startD);
            DateTime endDate = Convert.ToDateTime(endD);

            OutputResult outputResult = new OutputResult();

            Portfolios portfolios = new Portfolios();
            List<PositionsEntity> positionsEntitiesOri = new List<PositionsEntity>();
            List<BitcoinData> bitcoinDataOri = new List<BitcoinData>();

            List<PositionsEntity> positionsEntities = new List<PositionsEntity>();
            List<BitcoinData> bitcoinData = new List<BitcoinData>();

            List<FinalResult> finalResults = new List<FinalResult>();
            try
            {
                var table = AuthTable("Positions");
                positionsEntitiesOri = await GetPositionsAsync(table, user);
                positionsEntities = positionsEntitiesOri.OrderBy(s => s.TimeStamp).ToList();

                var tableBitCoin = AuthTable("CryptoCompareAPIDataFinal");
                bitcoinDataOri = await GetBitCoinDataAsync(tableBitCoin);
                bitcoinData = bitcoinDataOri.OrderBy(s => s.TimeStamp).ToList();

                var tableportfolios = AuthTable("Portfolios");
                portfolios = await GetPortfoliosDataAsync(tableportfolios, user);

                DateTime initDate = startDate;
                DateTime max = endDate;

                double noOfDaysD = (max - initDate).TotalDays;
                int noOfDays = (int)noOfDaysD;
                int noOfWeeks = (int)(noOfDays / 7);

                for (int i = 0; i < noOfWeeks; i++)
                {
                    DateTime newDate = initDate.AddDays(7);

                    List<BitcoinData> bitcoinDataTemp = new List<BitcoinData>();
                    bitcoinDataTemp = bitcoinData.Where(p => p.Timestamp > initDate && p.Timestamp <= newDate).ToList();
                    BitcoinData bitcoinValue = (bitcoinDataTemp.OrderByDescending(a => a.Timestamp).ToList()).FirstOrDefault();

                    List<PositionsEntity> positionsEntitiesTemp = new List<PositionsEntity>();
                    positionsEntitiesTemp = positionsEntities.Where(p => p.TimeStamp > initDate && p.TimeStamp < newDate).ToList();

                    List<PositionsEntity> positionsEntitiesTempBuy = positionsEntitiesTemp.Where(p => p.PositionType == "BUY").ToList();
                    int buy = 0;
                    foreach (var item in positionsEntitiesTempBuy)
                    {
                        buy = buy + item.Quantity;
                    }

                    List<PositionsEntity> positionsEntitiesTempsell = positionsEntitiesTemp.Where(p => p.PositionType == "SELL").ToList();
                    int sell = 0;
                    foreach (var item in positionsEntitiesTempsell)
                    {
                        sell = sell + item.Quantity;
                    }

                    if (bitcoinValue == null)
                    {
                        finalResults.Add
                        (
                            new FinalResult()
                            {
                                BitCoinOwned = (buy - sell),
                                CurrentBitCoinValue = null,
                                Week = "Week " + (i + 1).ToString(),
                                TimeStamp = newDate
                            }
                        );
                    }
                    else
                    {
                        finalResults.Add
                        (
                            new FinalResult()
                            {
                                BitCoinOwned = (buy - sell),
                                CurrentBitCoinValue = bitcoinValue.Close,
                                Week = "Week " + (i + 1).ToString(),
                                TimeStamp = newDate
                            }
                        );
                    }

                    initDate = newDate;

                }

                if(finalResults.Count > 20)
                {
                    finalResults = finalResults.GetRange(0, 20);
                }

                outputResult.FinalResults = finalResults;
                if(portfolios != null)
                {
                    outputResult.AccountBalance = portfolios.GBP;
                    outputResult.CurrentOwned = portfolios.BTC;
                }
            }
            catch (Exception ex)
            {

                throw;
            }
            return outputResult;
        }

        public Microsoft.WindowsAzure.Storage.Table.CloudTable AuthTable(string tableName)
        {
            string accountName = "sauokgp";
            string accountKey = "113mdwUqIiqt4K2HonK80HakIOplxYZINmQME5KB1IZfP+v3JHZK64wpoTP5NBFaG0MaO/TVqA0nW4KuCINTow==";
            try
            {
                Microsoft.WindowsAzure.Storage.Auth.StorageCredentials creds = new Microsoft.WindowsAzure.Storage.Auth.StorageCredentials(accountName, accountKey);
                Microsoft.WindowsAzure.Storage.CloudStorageAccount account = new Microsoft.WindowsAzure.Storage.CloudStorageAccount(creds, useHttps: true);

                Microsoft.WindowsAzure.Storage.Table.CloudTableClient client = account.CreateCloudTableClient();

                Microsoft.WindowsAzure.Storage.Table.CloudTable table = client.GetTableReference(tableName);

                return table;
            }
            catch
            {
                return null;
            }
        }

        public async Task<List<PositionsEntity>> GetPositionsAsync(Microsoft.WindowsAzure.Storage.Table.CloudTable table, string user)
        {
            Microsoft.WindowsAzure.Storage.Table.TableQuery<PositionsEntity> query = new Microsoft.WindowsAzure.Storage.Table.TableQuery<PositionsEntity>().Where("UserName eq '" + user + "'");
            var res = await table.ExecuteQuerySegmentedAsync(query, null);
            List<PositionsEntity> result = res.Results;
            return result;
        }

        public async Task<List<BitcoinData>> GetBitCoinDataAsync(Microsoft.WindowsAzure.Storage.Table.CloudTable table)
        {

            Microsoft.WindowsAzure.Storage.Table.TableQuery<BitcoinData> query = new Microsoft.WindowsAzure.Storage.Table.TableQuery<BitcoinData>();
            var res = await table.ExecuteQuerySegmentedAsync(query, null);
            List<BitcoinData> result = res.Results;
            return result;
        }

        public async Task<Portfolios> GetPortfoliosDataAsync(Microsoft.WindowsAzure.Storage.Table.CloudTable table, string user)
        {

            Microsoft.WindowsAzure.Storage.Table.TableQuery<Portfolios> query = new Microsoft.WindowsAzure.Storage.Table.TableQuery<Portfolios>().Where("PartitionKey eq '" + user.ToUpper() + "'"); ;
            var res = await table.ExecuteQuerySegmentedAsync(query, null);
            List<Portfolios> result = res.Results;
            List<Portfolios> resultNew = result.OrderByDescending(s => s.TimeStamp).ToList();

            return resultNew.FirstOrDefault();
        }
    }
}




