/** 
 * 
 * Created By Connor Taylor ct401
 * 
 * **/


using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Cosmos.Table;
using APIGroupProject.Models;
using APIGroupProject.Logging;
using APIGroupProject.Storage;
using System.Net.Http;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.Threading;

namespace APIGroupProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HelpPageController : ControllerBase
    {
        CloudTable HelpPageTable;
        ILogger logger;

        public HelpPageController(ITableClient client, ILogger _logger)
        {
            try
            {
                logger = _logger;
                HelpPageTable = client.GetTableReference("HelpPage");
            }
            catch (Exception e)
            {
                logger.LogMessage($"Failure to initialise:\n{e.Message}", 500);
            }
        }


        [HttpGet("data")]
        public async Task<IActionResult> GetHelpPageDataAsync(string search)
        {
            var searchy = search.ToUpper();

           // TableQuery<HelpPageEntity> tablesquery = new TableQuery<HelpPageEntity>().Where(
           //     TableQuery.CombineFilters(TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, searchy),
           //         TableOperators.And, TableQuery.CombineFilters(TableQuery.GenerateFilterCondition("RowKey", QueryComparisons.Equal, urls),
           //             TableOperators.And, TableQuery.GenerateFilterCondition("Titles", QueryComparisons.Equal, titles))));

            TableQuery<HelpPageEntity> tablesquery = new TableQuery<HelpPageEntity>().Where(TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, searchy));

            var theresult = HelpPageTable.ExecuteQuery(tablesquery);
            if (theresult.Count() == 0)
            {
                logger.LogMessage($"GetDataAsync - Search:{search}", 404);
                return new NotFoundResult();
            }
            return new OkObjectResult(theresult);
        }
    }
}