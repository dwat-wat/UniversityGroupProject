﻿/*
 * Created by Dexter Watson DAW35
 */

using Microsoft.Azure.Cosmos.Table;

namespace APIGroupProject.Storage
{
    public interface ITableClient
    {
        CloudTable GetTableReference(string table);
    }
}
