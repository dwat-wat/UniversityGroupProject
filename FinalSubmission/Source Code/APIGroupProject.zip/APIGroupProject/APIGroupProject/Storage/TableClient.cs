﻿/*
 * Created by Dexter Watson DAW35
 */

using System;
using Microsoft.Azure.Cosmos.Table;

namespace APIGroupProject.Storage
{
    public class TableClient : ITableClient
    {
        CloudStorageAccount storageAccount;
        CloudTableClient tableClient;

        public TableClient()
        {
            storageAccount = CloudStorageAccount.Parse(Environment.GetEnvironmentVariable("AzureStorage"));
            tableClient = storageAccount.CreateCloudTableClient();
        }

        public CloudTable GetTableReference(string table)
        {
            return tableClient.GetTableReference(table);
        }
    }
}
