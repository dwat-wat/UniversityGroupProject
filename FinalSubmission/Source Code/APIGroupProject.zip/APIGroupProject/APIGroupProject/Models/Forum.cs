﻿/*
 * Created by Mehmet Karauc MK622
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APIGroupProject.Models
{
    public class Forum
    {

        public DateTime timestamp { get; set; }
        public string userName { get; set; }
        public string question { get; set; }
        public string reply { get; set; }

    }
}
