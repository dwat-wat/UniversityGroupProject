/*
 * 
 * Created by Connor Taylor ct401
 * 
 */

using System;
using Microsoft.Azure.Cosmos.Table;

namespace APIGroupProject.Models
{
    public class HelpPageEntity : TableEntity
    {

        public string search { get; set; }
        public string urls { get; set; }
        public string titles { get; set; }


        public string Search
        {

            get
            {
                return search;
            }

            set
            {
                search = value;
            }
        }

        public string Urls
        {

            get
            {
                return urls;
            }

            set
            {
                urls = value;
            }
        }

        public string Titles
        {

            get
            {
                return titles;
            }

            set
            {
                titles = value;
            }
        }
    }
}
