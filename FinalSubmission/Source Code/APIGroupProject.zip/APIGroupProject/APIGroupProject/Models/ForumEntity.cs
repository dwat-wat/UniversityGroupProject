﻿/*
 * Created by Mehmet Karauc MK622
 */

using System;
using Microsoft.Azure.Cosmos.Table;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APIGroupProject.Models
{
    public class ForumEntity : TableEntity
    {
        private DateTime timestamp;
        private string userName;
        private string question;
        private string reply;

        public DateTime TimeStamp
        {

            get
            {
                return timestamp;
            }

            set
            {
                timestamp = value;
            }
        }

        public string UserName
        {

            get
            {
                return userName;
            }

            set
            {
                userName = value;
            }
        }

        public string Question
        {

            get
            {
                return question;
            }

            set
            {
                question = value;
            }
        }

        public string Reply
        {

            get
            {
                return reply;
            }

            set
            {
                reply = value;
            }
        }
    }
}
