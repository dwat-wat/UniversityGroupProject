﻿/*
 * Created by Mehmet Karauc MK622
 */

using System;

namespace APIGroupProject.Models
{
    public class Position { 

        public DateTime timestamp { get; set; }
        public string userName { get; set; }
        public string currency { get; set; }
        public int quantity { get; set; }
        public string positionType { get; set; }
        public string portfolio { get; set; }

    }
}
