﻿/*
 * Created by Dexter Watson DAW35
 */

namespace APIGroupProject.Models
{
    public class Account
    {
        public string region { get; set; }
        public string username { get; set; }
        public string password { get; set; }
    }
}
