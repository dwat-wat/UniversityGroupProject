﻿/*
 * Created by Mehmet Karauc MK622
 */

using System;

namespace APIGroupProject.Models
{
    public class ChatSystems {

        public DateTime timestamp { get; set; }
        public string userName { get; set; }
        public string history { get; set; }
        
    }
}
