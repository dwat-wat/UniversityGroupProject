/*
 * 
 * Created by Connor Taylor ct401
 * 
 */

using System;
using Microsoft.Azure.Cosmos.Table;

namespace APIGroupProject.Models
{
    public class LiveAndHistoricalDataEntity : TableEntity
    {

        private DateTime timestamp { get; set; }
        private double close { get; set; }
        private double high { get; set; }
        private double low { get; set; }
        private double open { get; set; }
        private string currency { get; set; }
        private int time { get; set; }


        public int Time
        {
            get
            {
                return time;
            }
            set
            {
                time = value;
            }
        }

        public DateTime TimeStamp
        {

            get
            {
                return timestamp;
            }

            set
            {
                timestamp = value;
            }
        }

        public double Close
        {

            get
            {
                return close;
            }

            set
            {
                close = value;
            }
        }

        public double High
        {

            get
            {
                return high;
            }

            set
            {
                high = value;
            }
        }

        public double Low
        {

            get
            {
                return low;
            }

            set
            {
                low = value;
            }
        }

        public double Open
        {

            get
            {
                return open;
            }

            set
            {
                open = value;
            }
        }

        public string Currency
        {

            get
            {
                return currency;
            }

            set
            {
                currency = value;
            }
        }
    }
}
