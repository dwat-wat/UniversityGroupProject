﻿/*
 * Created by Mehmet Karauc MK622
 */

using System;
using Microsoft.Azure.Cosmos.Table;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APIGroupProject.Models
{
    public class ChatSystemsEntity : TableEntity {

        private DateTime timestamp;
        private string userName;
        private string history;
        private Int64 time;

        public DateTime TimeStamp
        {

            get
            {
                return timestamp;
            }

            set
            {
                timestamp = value;
            }
        }
        
        public string UserName
        {

            get
            {
                return userName;
            }

            set
            {
                userName = value;
            }
        }

        public string History
        {

            get
            {
                return history;
            }

            set
            {
                history = value;
            }
        }

        public Int64 Time
        {
            get
            {
                return time;
            }

            set
            {
                this.time = value;
            }
        }
    }
}
