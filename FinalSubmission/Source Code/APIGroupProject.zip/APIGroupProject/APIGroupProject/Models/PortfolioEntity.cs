﻿/*
 * Created by Dexter Watson DAW35
 */

using Microsoft.Azure.Cosmos.Table;
using System;

namespace APIGroupProject.Models
{
    public class PortfolioEntity:TableEntity
    {
        private string userName;
        private string portfolio;
        private double gbp;
        private double btc;
        private DateTime start;
        private double startgbp;
        private bool deleted;

        public string Portfolio
        {
            get
            {
                return portfolio;
            }

            set
            {
                portfolio = value;
            }
        }

        public string UserName
        {
            get
            {
                return userName;
            }

            set
            {
                userName = value;
            }
        }

        public double GBP
        {
            get
            {
                return gbp;
            }
            set
            {
                gbp = value;
            }
        }

        public double BTC
        {
            get
            {
                return btc;
            }
            set
            {
                btc = value;
            }
        }

        public DateTime Start
        {
            get
            {
                return start;
            }
            set
            {
                start = value;
            }
        }

        public double StartGBP
        {
            get
            {
                return startgbp;
            }
            set
            {
                startgbp = value;
            }
        }

        public bool Deleted
        {
            get
            {
                return deleted;
            }
            set
            {
                deleted = value;
            }
        }
    }
}
