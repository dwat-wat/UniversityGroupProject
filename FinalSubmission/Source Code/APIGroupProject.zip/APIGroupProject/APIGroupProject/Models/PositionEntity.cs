﻿/*
 * Created by Mehmet Karauc MK622
 */

using System;
using Microsoft.Azure.Cosmos.Table;

namespace APIGroupProject.Models
{
    public class PositionEntity:TableEntity {

        private DateTime timestamp;
        private string userName;
        private string currency;
        private int quantity;
        private string positionType;
        private string portfolio;

        public DateTime TimeStamp {
            
            get
            {
                return timestamp;
            }

            set
            {
                timestamp = value;
            }
        }

        public string UserName {

            get
            {
                return userName;
            }

            set
            {
                userName = value;
            }
        }

        public string Currency {

            get {
                return currency;
            }

            set {
                currency = value;
            }
        }

        public int Quantity {

            get {
                return quantity;
            }

            set {
                quantity = value;
            }
        }

        public string PositionType {
            
            get {
                return positionType;
            }

            set {
                positionType = value;
            }
        }

        public string Portfolio {

            get
            {
                return portfolio;
            }

            set
            {
                portfolio = value;
            }
        }
    }
}
