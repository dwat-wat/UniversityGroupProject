﻿using Microsoft.Azure.Cosmos.Table;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APIGroupProject.Models
{
    public class CryptoDataEntity : TableEntity
    {
        private string currency;
        private string datetime;
        private double close;
        private double open;
        private double high;
        private double low;
        private Int64 time;

        public string Currency
        {
            get
            {
                return currency;
            }
            set
            {
                this.currency = value;
            }
        }
        public string DateTimeString
        {
            get
            {
                return datetime;
            }
            set
            {
                this.datetime = value;
            }
        }
        public double Open
        {
            get
            {
                return open;
            }
            set
            {
                this.open = value;
            }
        }
        public double Close
        {
            get
            {
                return close;
            }
            set
            {
                this.close = value;
            }
        }
        public double High
        {
            get
            {
                return high;
            }
            set
            {
                this.high = value;
            }
        }
        public double Low
        {
            get
            {
                return low;
            }
            set
            {
                this.low = value;
            }
        }
        public Int64 Time
        {
            get
            {
                return time;
            }
            set
            {
                this.time = value;
            }
        }
    }
}
