﻿/*
 * Created by Dexter Watson DAW35
 */

using Microsoft.Azure.Cosmos.Table;

namespace APIGroupProject.Models
{
    public class AccountEntity:TableEntity
    {
        private string region;
        private string userName;
        private string role;
        private byte[] passwordSalt;
        private byte[] passwordHash;
        private int passwordWorkFactor;
        private string selectedPortfolio;

        public string Region
        {
            get
            {
                return region;
            }

            set
            {
                region = value;
            }
        }

        public string UserName
        {
            get
            {
                return userName;
            }

            set
            {
                userName = value;
            }
        }

        public string Role
        {
            get
            {
                return role;
            }
            set
            {
                role = value;
            }
        }

        public byte[] PasswordSalt
        {
            get
            {
                return passwordSalt;
            }

            set
            {
                passwordSalt = value;
            }
        }

        public byte[] PasswordHash
        {
            get
            {
                return passwordHash;
            }

            set
            {
                passwordHash = value;
            }
        }

        public int PasswordWorkFactor
        {
            get
            {
                return passwordWorkFactor;
            }

            set
            {
                passwordWorkFactor = value;
            }
        }

        public string SelectedPortfolio
        {
            get
            {
                return selectedPortfolio;
            }
            set
            {
                selectedPortfolio = value;
            }
        }
    }
}
