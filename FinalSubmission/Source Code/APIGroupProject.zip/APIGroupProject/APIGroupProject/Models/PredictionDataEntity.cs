﻿
using Microsoft.Azure.Cosmos.Table;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APIGroupProject.Models
{
    public class PredictionDataEntity:TableEntity
    {
        private string currency;
        private string day;
        private double actual;
        private double rbf;
        private double linear;
        private double poly;
        private double comboV1;

        public string Currency
        {
            get
            {
                return currency;
            }

            set
            {
                currency = value;
            }
        }

        public string Day
        {
            get
            {
                return day;
            }

            set
            {
                day = value;
            }
        }

        public double Actual
        {
            get
            {
                return actual;
            }

            set
            {
                actual = value;
            }
        }

        public double RBF
        {
            get
            {
                return rbf;
            }

            set
            {
                rbf = value;
            }
        }

        public double Linear
        {
            get
            {
                return linear;
            }

            set
            {
                linear = value;
            }
        }

        public double Polynomial
        {
            get
            {
                return poly;
            }

            set
            {
                poly = value;
            }
        }

        public double ComboV1
        {
            get
            {
                return comboV1;
            }

            set
            {
                comboV1 = value;
            }
        }
    }
}
