/*
 * 
 * Created by Connor Taylor ct401
 * 
 */

using System;

namespace APIGroupProject.Models
{
    public class HelpPage
    {

        public string Search { get; set; }
        public string Urls { get; set; }
        public string Titles { get; set; }

    }
}