﻿/*
 * Created by Dexter Watson DAW35
 */

using Microsoft.Azure.Cosmos.Table;
using System;

namespace APITestProject.Common
{
    // Dummy class used for mocking the cloud table for unit testing purposes
    public class CloudTableMock : CloudTable
    {
        public CloudTableMock() : base(new Uri("http://empty.uri/"))
        {
        }
    }
}
