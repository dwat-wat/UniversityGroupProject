﻿/*
 * Created by Mehmet Karauc MK622
 */

using System;
using Xunit;
using APIGroupProject.Controllers;
using APIGroupProject.Models;
using NSubstitute;
using APIGroupProject.Logging;
using APIGroupProject.Storage;
using Microsoft.Azure.Cosmos.Table;
using System.Net.Http;
using System.Net;
using APITestProject.Common;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace APITestProject.ChatSystem
{
    public class ChatSystemTest
    {
        [Fact]
        public async void Chat_System_Returns()
        {
            try
            {
                var logger = Substitute.For<ILogger>();
                var tableclient = Substitute.For<ITableClient>();

                var cloudTable = Substitute.For<CloudTableMock>(); 
                var tableresult = new TableResult();
                tableresult.Result = new ChatSystemsEntity()
                {
                    PartitionKey = "TestUser",
                    RowKey = Guid.NewGuid().ToString(),
                    TimeStamp = DateTime.Now,
                    History = "Hello"
                };
                cloudTable.ExecuteAsync(Arg.Any<TableOperation>()).ReturnsForAnyArgs(new TableResult() { HttpStatusCode = 201 });
                tableclient.GetTableReference("ChatSystem").Returns<CloudTable>(cloudTable);

                ChatSystemController messages = new ChatSystemController(tableclient, logger);
                ChatSystems message = new ChatSystems()
                {
                    userName = "TestUser",
                    timestamp = DateTime.Now,
                    history = "Hello"
                };

                HttpResponseMessage result = await messages.NewAsync(message) as HttpResponseMessage;

                // Assert (Assert that the results are as expected)
                Assert.NotNull(cloudTable.ReceivedCalls());
                Assert.Equal(HttpStatusCode.Created, result.StatusCode);
            }
            catch (Exception e)
            {
                Assert.False(true, e.Message);
            }
        }

        /*[Fact]
        public async void Get_Returns200Ok()
        {
            try
            {
                // Arrange (Set-up all the objects required for the test)
                // Mock the logger and the table client
                var logger = Substitute.For<ILogger>();
                var tableclient = Substitute.For<ITableClient>();

                // Mock the Accounts table
                var cloudTable = Substitute.For<CloudTableMock>();
                var tableresult = new ChatSystemsEntity()
                {
                    PartitionKey = "TestUser",
                    RowKey = Guid.NewGuid().ToString(),
                    TimeStamp = DateTime.Now,
                    History = "Hello"
                };
                var listresult = new List<ChatSystemsEntity>() { tableresult };
                cloudTable.ExecuteQuery(new TableQuery<ChatSystemsEntity>().Where(
                    TableQuery.CombineFilters(
                    TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, "TestUser"),
                    TableOperators.And,
                        TableQuery.GenerateFilterCondition("History", QueryComparisons.Equal, "hello")))).ReturnsForAnyArgs(listresult);

                // Mock the GetTableReference method to return the mocked Accounts table
                tableclient.GetTableReference("ChatSystem").Returns<CloudTable>(cloudTable);

                // Set up the accounts controller
                ChatSystemController chat = new ChatSystemController(tableclient, logger);

                // Act (Run the action you want to test)
                var result = await chat.GetMessageAsync("TestUser", "hello") as OkObjectResult;

                // Assert (Assert that the results are as expected)
                Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
                Assert.NotNull(result);
            }
            catch (Exception e)
            {
                Assert.False(true, e.Message);
            }
        }*/
    }
}





