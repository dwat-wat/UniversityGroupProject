﻿/*
 * Created by Mehmet Karauc MK622
 */

using System;
using Xunit;
using APIGroupProject.Controllers;
using APIGroupProject.Models;
using NSubstitute;
using APIGroupProject.Logging;
using APIGroupProject.Storage;
using Microsoft.Azure.Cosmos.Table;
using System.Net.Http;
using System.Net;
using APITestProject.Common;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace APITestProject.Positions
{
    public class PositionsTest
    {
        [Fact]
        public async void Position_Returns()
        {
            try
            {
                var logger = Substitute.For<ILogger>();
                var tableclient = Substitute.For<ITableClient>();

                var cloudTable = Substitute.For<CloudTableMock>();
                var tableresult = new TableResult();
                tableresult.Result = new PositionEntity()
                {                                       
                    PartitionKey = "BITCOIN",
                    RowKey = Guid.NewGuid().ToString(),
                    TimeStamp = new DateTime(1),
                    UserName = "TestUser",
                    Quantity = 2,
                    PositionType = "Buy",
                    Portfolio = "TestPortfolio"
                };
                cloudTable.ExecuteAsync(Arg.Any<TableOperation>()).ReturnsForAnyArgs(new TableResult() { HttpStatusCode = 201 });
                tableclient.GetTableReference("Positions").Returns<CloudTable>(cloudTable);

                PositionsController positions = new PositionsController(tableclient, logger);
                Position position = new Position()
                {
                    currency = "BITCOIN",
                    positionType = "BUY",
                    quantity = 2,
                    timestamp = new DateTime(1),
                    userName = "TestUser",
                    portfolio = "TestPortfolio"
                };

                HttpResponseMessage result = await positions.NewAsync(position) as HttpResponseMessage;

                // Assert (Assert that the results are as expected)
                Assert.NotNull(cloudTable.ReceivedCalls());
                Assert.Equal(HttpStatusCode.Created, result.StatusCode);
            }
            catch (Exception e)
            {
                Assert.False(true, e.Message);
            }
        }

        [Fact]
        public async void Get_Return200Ok()
        {
            try
            {
                // Arrange (Set-up all the objects required for the test)
                // Mock the logger and the table client
                var logger = Substitute.For<ILogger>();
                var tableclient = Substitute.For<ITableClient>();

                // Mock the Accounts table
                var cloudTable = Substitute.For<CloudTableMock>();
                var tableresult = new PositionEntity()
                {
                    PartitionKey = "BITCOIN",
                    RowKey = Guid.NewGuid().ToString(),
                    TimeStamp = new DateTime(1),
                    UserName = "TestUser",
                    Quantity = 2,
                    PositionType = "Buy",
                    Portfolio = "TestPortfolio"
                };
                var listresult = new List<PositionEntity>() { tableresult };
                cloudTable.ExecuteQuery(new TableQuery<PositionEntity>().Where(
                    TableQuery.CombineFilters(
                    TableQuery.GenerateFilterCondition("UserName", QueryComparisons.Equal, "TestUser"),
                    TableOperators.And,
                        TableQuery.GenerateFilterCondition("Portfolio", QueryComparisons.Equal, "portfolio1")))).ReturnsForAnyArgs(listresult);

                // Mock the GetTableReference method to return the mocked Accounts table
                tableclient.GetTableReference("Positions").Returns<CloudTable>(cloudTable);

                // Set up the accounts controller
                PositionsController positions = new PositionsController(tableclient, logger);

                // Act (Run the action you want to test)
                var result = await positions.GetPositionsAsync("TestUser", "Portfoli1") as OkObjectResult;

                // Assert (Assert that the results are as expected)
                Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
                Assert.NotNull(result);
            }
            catch (Exception e)
            {
                Assert.False(true, e.Message);
            }
        }

        [Fact]
        public async void Get_Returns200Ok()
        {
            try
            {
                // Arrange (Set-up all the objects required for the test)
                // Mock the logger and the table client
                var logger = Substitute.For<ILogger>();
                var tableclient = Substitute.For<ITableClient>();

                // Mock the Accounts table
                var cloudTable = Substitute.For<CloudTableMock>();
                var tableresult = new PositionEntity()
                {
                    PartitionKey = "BITCOIN",
                    RowKey = Guid.NewGuid().ToString(),
                    TimeStamp = new DateTime(1),
                    UserName = "TestUser",
                    Quantity = 2,
                    PositionType = "Buy",
                    Portfolio = "TestPortfolio"
                };
                var listresult = new List<PositionEntity>() { tableresult };
                cloudTable.ExecuteQuery(new TableQuery<PositionEntity>().Where(
                    TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, "TestUser"))).ReturnsForAnyArgs(listresult);

                // Mock the GetTableReference method to return the mocked Accounts table
                tableclient.GetTableReference("Positions").Returns<CloudTable>(cloudTable);

                // Set up the accounts controller
                PositionsController positions = new PositionsController(tableclient, logger);

                // Act (Run the action you want to test)
                var result = await positions.GetPositionsAsync("TestUser", "Portfoli1") as OkObjectResult;

                // Assert (Assert that the results are as expected)
                Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
                Assert.NotNull(result);
            }
            catch (Exception e)
            {
                Assert.False(true, e.Message);
            }
        }
    }
}
