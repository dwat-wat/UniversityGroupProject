/*
 * Created by Dexter Watson DAW35
 */

using System;
using Xunit;
using APIGroupProject.Controllers;
using APIGroupProject.Models;
using NSubstitute;
using APIGroupProject.Logging;
using APIGroupProject.Storage;
using Microsoft.Azure.Cosmos.Table;
using System.Net.Http;
using System.Net;
using APITestProject.Common;
using Microsoft.AspNetCore.Mvc;

namespace APITestProject.Portfolio
{
    public class PortfolioTest
    {
        [Fact]
        public async void GetPortfolio_Returns200Ok()
        {
            try
            {
                // Arrange (Set-up all the objects required for the test)
                // Mock the logger and the table client
                var logger = Substitute.For<ILogger>();
                var tableclient = Substitute.For<ITableClient>();

                // Mock the Portfolio table
                var cloudTable = Substitute.For<CloudTableMock>();
                var cloudTableAcc = Substitute.For<CloudTableMock>();
                var tableresult = new TableResult();
                tableresult.Result = new PortfolioEntity()
                {
                    PartitionKey = "TestUser",
                    UserName = "TestUser",
                    RowKey = "TestPortfolio",
                    Portfolio = "TestPortfolio",
                    GBP = 1000.0,
                    BTC = 2.0
                };
                var tableresultacc = new TableResult();
                var acc = new AccountEntity()
                {
                    PartitionKey = "UK",
                    UserName = "TestUser",
                    RowKey = "TestUser",
                    SelectedPortfolio = "TestPortfolio",
                    ETag = "123"
                };
                tableresultacc.Result = acc;
                cloudTable.ExecuteAsync(TableOperation.Retrieve<PortfolioEntity>(partitionKey: "TESTUSER", rowkey: "TESTPORTFOLIO")).ReturnsForAnyArgs<TableResult>(tableresult);

                cloudTableAcc.ExecuteAsync(TableOperation.Retrieve<AccountEntity>("UK", "TESTUSER")).ReturnsForAnyArgs<TableResult>(tableresultacc);
                cloudTableAcc.ExecuteAsync(TableOperation.Merge(acc)).ReturnsForAnyArgs<TableResult>(tableresultacc);

                // Mock the GetTableReference method to return the mocked Portfolios table
                tableclient.GetTableReference("Portfolios").Returns<CloudTable>(cloudTable);
                // Mock the GetTableReference method to return the mocked Accounts table
                tableclient.GetTableReference("Accounts").Returns<CloudTable>(cloudTableAcc);

                // Set up the portfolio controller
                PortfolioController portfolios = new PortfolioController(tableclient, logger);

                // Act (Run the action you want to test)
                var result = await portfolios.GetPortfolioAsync("TestUser", "TestPortfolio") as OkObjectResult;

                // Assert (Assert that the results are as expected)
                Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
                Assert.NotNull(result);
            }
            catch (Exception e)
            {
                Assert.False(true, e.Message);
            }
        }

        [Fact]
        public async void UpdatePortfolio_Returns404NotFound()
        {
            try
            {
                // Arrange (Set-up all the objects required for the test)
                // Mock the logger and the table client
                var logger = Substitute.For<ILogger>();
                var tableclient = Substitute.For<ITableClient>();

                // Mock the Portfolio table
                var cloudTable = Substitute.For<CloudTableMock>();
                var tableresult = new TableResult()
                {
                    HttpStatusCode = (int)HttpStatusCode.NotFound,
                    Result = new PortfolioEntity()
                };
                cloudTable.ExecuteAsync(TableOperation.Retrieve<PortfolioEntity>(partitionKey: "TestUser", rowkey: "TestPortfolio")).ReturnsForAnyArgs<TableResult>(tableresult);

                // Mock the GetTableReference method to return the mocked Accounts table
                tableclient.GetTableReference("Portfolios").Returns<CloudTable>(cloudTable);

                // Set up the accounts controller
                PortfolioController portfolios = new PortfolioController(tableclient, logger);

                // Act (Run the action you want to test)
                var result = await portfolios.UpdatePortfolio("TestUser", "TestPortfolio", 1000, 2) as NotFoundResult;

                // Assert (Assert that the results are as expected)
                Assert.Equal((int)HttpStatusCode.NotFound, result.StatusCode);
            }
            catch (Exception e)
            {
                Assert.False(true, e.Message);
            }
        }

        [Fact]
        public async void UpdatePortfolio_Returns201Created()
        {
            try
            {
                // Arrange (Set-up all the objects required for the test)
                // Mock the logger and the table client
                var logger = Substitute.For<ILogger>();
                var tableclient = Substitute.For<ITableClient>();

                // Mock the portfolios table
                var cloudTable = Substitute.For<CloudTableMock>();
                var tableresult = new TableResult()
                {
                    HttpStatusCode = (int)HttpStatusCode.OK,
                    Result = new PortfolioEntity()
                };
                cloudTable.ExecuteAsync(TableOperation.Retrieve<AccountEntity>(partitionKey: "TestUser", rowkey: "TestPortfolio")).ReturnsForAnyArgs<TableResult>(tableresult);

                // Mock the GetTableReference method to return the mocked Portfolios table
                tableclient.GetTableReference("Portfolios").Returns<CloudTable>(cloudTable);

                // Set up the accounts controller
                PortfolioController accounts = new PortfolioController(tableclient, logger);

                // Act (Run the action you want to test)
                var result = await accounts.UpdatePortfolio("TestUser", "TestPortfolio", 1000, 3) as CreatedResult;

                // Assert (Assert that the results are as expected)
                Assert.Equal((int) HttpStatusCode.Created, result.StatusCode);
            }
            catch (Exception e)
            {
                Assert.False(true, e.Message);
            }
        }

        [Fact]
        public async void New_Returns201Created()
        {
            try
            {
                // Arrange (Set-up all the objects required for the test)
                // Mock the logger and the table client
                var logger = Substitute.For<ILogger>();
                var tableclient = Substitute.For<ITableClient>();

                // Mock the Portfolios table
                var cloudTable = Substitute.For<CloudTableMock>();
                var tableresult = new TableResult()
                {
                    HttpStatusCode = (int)HttpStatusCode.NotFound,
                    Result = new PortfolioEntity()
                };
                cloudTable.ExecuteAsync(TableOperation.Retrieve<PortfolioEntity>(partitionKey:"TestUser", rowkey:"TestPortfolio")).ReturnsForAnyArgs<TableResult>(tableresult);
                
                // Mock the GetTableReference method to return the mocked Accounts table
                tableclient.GetTableReference("Portfolios").Returns<CloudTable>(cloudTable);

                // Set up the accounts controller
                PortfolioController accounts = new PortfolioController(tableclient, logger);

                // Act (Run the action you want to test)
                var result = await accounts.NewPortfolioAsync("TestUser", "TestPortfolio", 1000) as CreatedResult;

                // Assert (Confirm that the results are as expected)
                Assert.Equal((int) HttpStatusCode.Created, result.StatusCode);
                Assert.NotNull(result);
            }
            catch (Exception e)
            {
                Assert.False(true, e.Message);
            }
        }
        
        [Fact]
        public async void NewPortfolio_Returns400BadRequest()
        {
            try
            {
                // Arrange (Set-up all the objects required for the test)
                // Mock the logger and the table client
                var logger = Substitute.For<ILogger>();
                var tableclient = Substitute.For<ITableClient>();

                // Mock the Portfolios table
                var cloudTable = Substitute.For<CloudTableMock>();
                var tableresult = new TableResult()
                {
                    HttpStatusCode = (int)HttpStatusCode.OK
                };
                cloudTable.ExecuteAsync(TableOperation.Retrieve<PortfolioEntity>(partitionKey: "TestUser", rowkey: "TestPortfolio")).ReturnsForAnyArgs<TableResult>(tableresult);

                // Mock the GetTableReference method to return the mocked Accounts table
                tableclient.GetTableReference("Portfolios").Returns<CloudTable>(cloudTable);

                // Set up the accounts controller
                PortfolioController accounts = new PortfolioController(tableclient, logger);

                // Act (Run the action you want to test)
                var result = await accounts.NewPortfolioAsync("TestUser", "TestPortfolio", 1000) as BadRequestResult;

                // Assert (Confirm that the results are as expected)
                Assert.Equal((int) HttpStatusCode.BadRequest, result.StatusCode);
            }
            catch (Exception e)
            {
                Assert.False(true, e.Message);
            }
        }

        [Fact]
        public async void DeletePortfolio_Returns200()
        {
            try
            {
                // Arrange (Set-up all the objects required for the test)
                // Mock the logger and the table client
                var logger = Substitute.For<ILogger>();
                var tableclient = Substitute.For<ITableClient>();

                // Mock the Portfolios table
                var cloudTable = Substitute.For<CloudTableMock>();
                var tableresult = new TableResult()
                {
                    HttpStatusCode = (int)HttpStatusCode.OK,
                    Result = new PortfolioEntity()
                };
               
                cloudTable.ExecuteAsync(TableOperation.Retrieve<PortfolioEntity>(partitionKey: "TestUser", rowkey: "TestPortfolio")).ReturnsForAnyArgs<TableResult>(tableresult);


                // Mock the GetTableReference method to return the mocked Accounts table
                tableclient.GetTableReference("Portfolios").Returns<CloudTable>(cloudTable);

                // Set up the accounts controller
                PortfolioController accounts = new PortfolioController(tableclient, logger);

                // Act (Run the action you want to test)
                var result = await accounts.DeletePortfolio("TestUser", "TestPortfolio") as OkResult;

                // Assert (Confirm that the results are as expected)
                Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
            }
            catch (Exception e)
            {
                Assert.False(true, e.Message);
            }
        }
    }
}
