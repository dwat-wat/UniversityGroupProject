/*
 * Created by Dexter Watson DAW35
 */

using System;
using Xunit;
using APIGroupProject.Controllers;
using APIGroupProject.Models;
using NSubstitute;
using APIGroupProject.Logging;
using APIGroupProject.Storage;
using Microsoft.Azure.Cosmos.Table;
using System.Net.Http;
using System.Net;
using APITestProject.Common;
using Microsoft.AspNetCore.Mvc;

namespace APITestProject.Accounts
{
    public class AccountsTests
    {
        [Fact]
        public async void Login_Returns200Ok()
        {
            try
            {
                // Arrange (Set-up all the objects required for the test)
                // Mock the logger and the table client
                var logger = Substitute.For<ILogger>();
                var tableclient = Substitute.For<ITableClient>();

                // Mock the Accounts table
                var cloudTable = Substitute.For<CloudTableMock>();
                var tableresult = new TableResult();
                tableresult.Result = new AccountEntity()
                {
                    PartitionKey = "UK",
                    Region = "UK",
                    PasswordSalt = new byte[] { 230, 55, 87, 108, 204, 182, 79, 227, 252 },
                    PasswordHash = new byte[] { 247, 192, 184, 145, 207, 118, 22, 18, 13 },
                    PasswordWorkFactor = 1,
                    Timestamp = new DateTime(1),
                    UserName = "TestUser"
                };
                cloudTable.ExecuteAsync(TableOperation.Retrieve<AccountEntity>(partitionKey:"UK", rowkey:"TestUser")).ReturnsForAnyArgs<TableResult>(tableresult);

                // Mock the GetTableReference method to return the mocked Accounts table
                tableclient.GetTableReference("Accounts").Returns<CloudTable>(cloudTable);

                // Set up the accounts controller
                AccountsController accounts = new AccountsController(tableclient, logger);
                Account account = new Account()
                {
                    region = "UK",
                    username = "TestUser",
                    password = "Password1"
                };

                // Act (Run the action you want to test)
                HttpResponseMessage result = await accounts.LoginAsync(account) as HttpResponseMessage;

                // Assert (Assert that the results are as expected)
                Assert.Equal(HttpStatusCode.OK, result.StatusCode);
                Assert.NotNull(result.Content);
            }
            catch(Exception e)
            {
                Assert.False(true, e.Message);
            }
        }

        [Fact]
        public async void Login_PasswordIncorrect_Returns400BadRequest()
        {
            try
            {
                // Arrange (Set-up all the objects required for the test)
                // Mock the logger and the table client
                var logger = Substitute.For<ILogger>();
                var tableclient = Substitute.For<ITableClient>();

                // Mock the Accounts table
                var cloudTable = Substitute.For<CloudTableMock>();
                var tableresult = new TableResult();
                tableresult.Result = new AccountEntity()
                {
                    PartitionKey = "UK",
                    Region = "UK",
                    PasswordSalt = new byte[] { 230, 55, 87, 108, 204, 182, 79, 227, 252 },
                    PasswordHash = new byte[] { 247, 192, 184, 145, 207, 118, 22, 18, 14 },
                    PasswordWorkFactor = 1,
                    Timestamp = new DateTime(1),
                    UserName = "TestUser"
                };
                cloudTable.ExecuteAsync(TableOperation.Retrieve<AccountEntity>(partitionKey: "UK", rowkey: "TestUser")).ReturnsForAnyArgs<TableResult>(tableresult);

                // Mock the GetTableReference method to return the mocked Accounts table
                tableclient.GetTableReference("Accounts").Returns<CloudTable>(cloudTable);

                // Set up the accounts controller
                AccountsController accounts = new AccountsController(tableclient, logger);
                Account account = new Account()
                {
                    region = "UK",
                    username = "TestUser",
                    password = "Password1"
                };

                // Act (Run the action you want to test)
                HttpResponseMessage result = await accounts.LoginAsync(account) as HttpResponseMessage;

                // Assert (Assert that the results are as expected)
                Assert.Equal(HttpStatusCode.BadRequest, result.StatusCode);
            }
            catch (Exception e)
            {
                Assert.False(true, e.Message);
            }
        }

        [Fact]
        public async void Login_UserDoesntExist_Returns400BadRequest()
        {
            try
            {
                // Arrange (Set-up all the objects required for the test)
                // Mock the logger and the table client
                var logger = Substitute.For<ILogger>();
                var tableclient = Substitute.For<ITableClient>();

                // Mock the Accounts table
                var cloudTable = Substitute.For<CloudTableMock>();
                var tableresult = new TableResult();
                tableresult.Result = null;
                cloudTable.ExecuteAsync(TableOperation.Retrieve<AccountEntity>(partitionKey: "UK", rowkey: "TestUser")).ReturnsForAnyArgs<TableResult>(tableresult);

                // Mock the GetTableReference method to return the mocked Accounts table
                tableclient.GetTableReference("Accounts").Returns<CloudTable>(cloudTable);

                // Set up the accounts controller
                AccountsController accounts = new AccountsController(tableclient, logger);
                Account account = new Account()
                {
                    region = "UK",
                    username = "TestUser",
                    password = "Password1"
                };

                // Act (Run the action you want to test)
                HttpResponseMessage result = await accounts.LoginAsync(account) as HttpResponseMessage;

                // Assert (Assert that the results are as expected)
                Assert.Equal(HttpStatusCode.BadRequest, result.StatusCode);
            }
            catch (Exception e)
            {
                Assert.False(true, e.Message);
            }
        }

        [Fact]
        public async void New_Returns201Created()
        {
            try
            {
                // Arrange (Set-up all the objects required for the test)
                // Mock the logger and the table client
                var logger = Substitute.For<ILogger>();
                var tableclient = Substitute.For<ITableClient>();                

                // Mock the Accounts table
                var cloudTable = Substitute.For<CloudTableMock>();
                var cloudTablePort = Substitute.For<CloudTableMock>();
                var tableresult = new TableResult()
                {
                    HttpStatusCode = (int)HttpStatusCode.NotFound,
                    Result = new AccountEntity()
                };
                cloudTable.ExecuteAsync(TableOperation.Retrieve<AccountEntity>(partitionKey:"UK", rowkey:"TestUser")).ReturnsForAnyArgs<TableResult>(tableresult);



                // Mock the GetTableReference method to return the mocked Accounts table
                tableclient.GetTableReference("Accounts").Returns<CloudTable>(cloudTable);
                tableclient.GetTableReference("Portfolios").Returns<CloudTable>(cloudTablePort);

                // Set up the accounts controller
                AccountsController accounts = new AccountsController(tableclient, logger);
                Account account = new Account()
                {
                    region = "UK",
                    username = "TestUser",
                    password = "Password1"
                };

                // Act (Run the action you want to test)
                HttpResponseMessage result = await accounts.NewAsync(account) as HttpResponseMessage;

                // Assert (Confirm that the results are as expected)
                Assert.Equal(HttpStatusCode.Created, result.StatusCode);
                Assert.NotNull(result.Content);
            }
            catch (Exception e)
            {
                Assert.False(true, e.Message);
            }
        }
        
        [Fact]
        public async void New_Returns400BadRequest()
        {
            try
            {
                // Arrange (Set-up all the objects required for the test)
                // Mock the logger and the table client
                var logger = Substitute.For<ILogger>();
                var tableclient = Substitute.For<ITableClient>();

                // Mock the Accounts table
                var cloudTable = Substitute.For<CloudTableMock>();
                var tableresult = new TableResult()
                {
                    HttpStatusCode = (int)HttpStatusCode.OK
                };
                cloudTable.ExecuteAsync(TableOperation.Retrieve<AccountEntity>(partitionKey: "UK", rowkey: "TestUser")).ReturnsForAnyArgs<TableResult>(tableresult);

                // Mock the GetTableReference method to return the mocked Accounts table
                tableclient.GetTableReference("Accounts").Returns<CloudTable>(cloudTable);

                // Set up the accounts controller
                AccountsController accounts = new AccountsController(tableclient, logger);
                Account account = new Account()
                {
                    region = "UK",
                    username = "TestUser",
                    password = "Password1"
                };

                // Act (Run the action you want to test)
                HttpResponseMessage result = await accounts.NewAsync(account) as HttpResponseMessage;

                // Assert (Confirm that the results are as expected)
                Assert.Equal(HttpStatusCode.BadRequest, result.StatusCode);
            }
            catch (Exception e)
            {
                Assert.False(true, e.Message);
            }
        }
    }
}
