/*
 * Created by Dexter Watson DAW35
 */

using System;
using Xunit;
using APIGroupProject.Controllers;
using APIGroupProject.Models;
using NSubstitute;
using APIGroupProject.Logging;
using APIGroupProject.Storage;
using Microsoft.Azure.Cosmos.Table;
using System.Net.Http;
using System.Net;
using APITestProject.Common;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace APITestProject.Prediction
{
    public class PredictionDataTests
    {
        [Fact]
        public async void Get_Returns200Ok()
        {
            try
            {
                // Arrange (Set-up all the objects required for the test)
                // Mock the logger and the table client
                var logger = Substitute.For<ILogger>();
                var tableclient = Substitute.For<ITableClient>();

                // Mock the Accounts table
                var cloudTable = Substitute.For<CloudTableMock>();
                var tableresult = new PredictionDataEntity()
                {
                    PartitionKey = "BTC",
                    RowKey = "",
                    Currency = "BTC",
                    Day = "",
                    Actual = 0.0,
                    RBF = 0.0,
                    Linear = 0.0,
                    Timestamp = new DateTime(1)
                };
                var listresult = new List<PredictionDataEntity>() { tableresult };
                cloudTable.ExecuteQuery(new TableQuery<PredictionDataEntity>().Where(
                TableQuery.CombineFilters(
                    TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, "BTC"),
                    TableOperators.And,
                    TableQuery.CombineFilters(
                        TableQuery.GenerateFilterCondition("RowKey", QueryComparisons.GreaterThan, "20001"),
                        TableOperators.And,
                        TableQuery.GenerateFilterCondition("RowKey", QueryComparisons.LessThan, "20002"))))).ReturnsForAnyArgs<IEnumerable<PredictionDataEntity>>(listresult);

                // Mock the GetTableReference method to return the mocked Accounts table
                tableclient.GetTableReference("PredictionData").Returns<CloudTable>(cloudTable);

                // Set up the accounts controller
                PredictionController predictiondata = new PredictionController(tableclient, logger);

                // Act (Run the action you want to test)
                var result = await predictiondata.GetDataAsync("BTC", DateTime.Parse("01-01-2020"), DateTime.Parse("01-02-2020")) as OkObjectResult;

                // Assert (Assert that the results are as expected)
                Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
                Assert.NotNull(result);
            }
            catch(Exception e)
            {
                Assert.False(true, e.Message);
            }
        }
    }
}
